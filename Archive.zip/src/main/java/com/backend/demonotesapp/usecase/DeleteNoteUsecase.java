package com.backend.demonotesapp.usecase;

public interface DeleteNoteUsecase {
    void execute(Long id);
}
