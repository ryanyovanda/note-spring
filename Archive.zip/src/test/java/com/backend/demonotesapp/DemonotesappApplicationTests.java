package com.backend.demonotesapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemonotesappApplicationTests {

    @Test
    void contextLoads() {
    }

}
